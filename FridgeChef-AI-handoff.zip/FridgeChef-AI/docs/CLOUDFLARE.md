# Cloudflare 部署与更新

拥有者负责 Cloudflare 账号、部署和线上 Secret。同学交回 API 代码及变量说明，不需要登录拥有者的 Cloudflare。

本次实际网址和验证结果见 [部署记录](DEPLOYMENT-STATUS.md)。首次部署不配置真实 AI 密钥，可使用“範例體驗”。网站和 AI 使用云端服务后，个人电脑关闭不会影响使用。

## 首次部署或换电脑

安装 Node.js 24、pnpm 11.25.0，在包含 `package.json` 的目录执行：

```sh
pnpm install --frozen-lockfile
pnpm exec wrangler login
pnpm run build
pnpm exec wrangler deploy --config dist/server/wrangler.json
```

由拥有者在浏览器完成授权，最后一条命令发布网站。第一次使用账号时，还需要按提示注册 `workers.dev` 免费网址前缀。以终端实际返回的网址为准。

Worker 名称为 `fridgechef-ai`，首次部署确认没有其他同名项目；以后沿用同名更新。本项目由 `vite.config.ts` 生成 `dist/server/wrangler.json`，不需要套用其他项目的 OpenNext 迁移步骤。

若依赖已安装、但 pnpm 的本机环境阻断运行，可直接使用：

```sh
node scripts/run-framework.mjs build
node --import ./scripts/sites-env.mjs ./node_modules/wrangler/bin/wrangler.js deploy --config dist/server/wrangler.json
```

这是完整 Worker 部署，不是只上传 `public/` 或离线 HTML。

## 同学接好 API 后启用

1. 更新同学交回的代码，安装依赖、构建、部署。
2. 打开 [Cloudflare 控制台](https://dash.cloudflare.com/)，进入 **Workers & Pages → fridgechef-ai**。
3. 找到 **Settings → Variables and Secrets**，新增变量，选择 **Secret** 类型。
4. 若继续使用现有代码，名称填 `SILICONFLOW_API_KEY`，值填写实际密钥。
5. 保存，完成界面要求的部署步骤。若更换提供商，采用同学交回的变量名。
6. 查看线上 `/api/health`，再实际识别图片、生成三道菜。

也可以安全地在终端提示处输入密钥：

```sh
pnpm exec wrangler secret put SILICONFLOW_API_KEY --config dist/server/wrangler.json
```

不要把密钥写成命令参数，不要上传 `.env.local`。本地文件不会自动成为 Cloudflare Secret。
`configured: true` 只说明存在配置，还要验证真实调用。

现有模型有代码默认值，无须额外配置。若同学更换模型并使用普通环境变量，请把对应变量纳入 Worker/Vite 配置，避免后续部署覆盖控制台手动添加的普通变量。

## 日后更新

在同一个项目目录执行：

```sh
pnpm install --frozen-lockfile
pnpm run build
pnpm exec wrangler deploy --config dist/server/wrangler.json
```

沿用同一个 Worker 名称和网址，保留线上 Secret。

## 运行时间与额度

正常部署可以长期保留，不需要自己的电脑常开。实际可用性取决于账号、Cloudflare 方案及 AI 服务状态。截至交接日，Workers 免费方案每天有 100,000 次动态请求等资源限制。外部 AI 额度另计，托管免费不等于 AI 调用永久免费。

官方资料：[Vinext](https://developers.cloudflare.com/workers/framework-guides/web-apps/nextjs/)、[Vite 部署](https://developers.cloudflare.com/workers/vite-plugin/get-started/)、[Secrets](https://developers.cloudflare.com/workers/configuration/secrets/)、[限制](https://developers.cloudflare.com/workers/platform/limits/)。
