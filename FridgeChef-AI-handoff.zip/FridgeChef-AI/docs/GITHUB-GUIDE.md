# 上传 GitHub、下载和交回项目

GitHub 在这里存放项目，网站由 Cloudflare 部署。公开仓库人人能下载，但不会自动获得修改你仓库的权限。

## 最简单：浏览器上传交接压缩包

1. 登录 [GitHub](https://github.com/)，打开 [新建仓库](https://github.com/new)。
2. 名称填 `FridgeChef-AI`，选择 **Public**，勾选添加 README，点击 **Create repository**。
3. 在仓库点击 **Add file → Upload files**。
4. 拖入本次的 `FridgeChef-AI-handoff.zip`，填写“上传项目交接包”并提交保存；按钮可能显示 **Commit changes** 或要求提出变更，按页面完成保存。
5. 可编辑仓库 README，写“请下载 FridgeChef-AI-handoff.zip，解压后先看 README.md 与 docs/HANDOFF.md”。
6. 复制仓库网址发给同学。

压缩包内部含全部源码和交接文档，但 GitHub 网页不会直接展示 ZIP 内的文件目录。若要在线查看代码或长期协作，用下一种方式。

网页上传每文件最多 25 MiB、一次最多 100 文件，本次 ZIP 小于限制。更新项目时替换 ZIP。[官方上传说明](https://docs.github.com/en/repositories/working-with-files/managing-files/adding-a-file-to-a-repository)

## 长期协作：GitHub Desktop 上传完整源码

1. 安装 [GitHub Desktop](https://desktop.github.com/)，登录自己的账号。
2. 解压本次分享包，找到包含 `package.json` 的干净目录。使用这个副本，不要选择含本地密钥和旧历史的原开发目录。
3. 在 Desktop 点击 **File → Add local repository**，选择这个目录。
4. 若提示不是 Git 仓库，选择 **create a repository here** 在当前目录建立。不要覆盖已有 README、`.gitignore`，不要再套一层同名文件夹。
5. 检查列表应有 `app/`、`lib/`、`docs/`、`.env.example`、`.openai/hosting.json`，不应有 `.env.local`、依赖或缓存；如有未提交变更，填写说明并提交。
6. 点击 **Publish repository**，填写自己账号下尚未使用的名称。
7. **取消 Keep this code private**，发布公开仓库。
8. 打开 GitHub 页面，确认根目录直接有 `package.json`、`README.md`、`app/` 和 `docs/`，复制网址给同学。

若已经用浏览器方式创建同名仓库，可把完整源码仓库命名为 `FridgeChef-AI-source`，避免初次操作要处理远程仓库冲突。[官方 Desktop 发布说明](https://docs.github.com/en/desktop/adding-and-cloning-repositories/adding-an-existing-project-to-github-using-github-desktop)

## 同学如何下载

如果仓库里是交接 ZIP：点击 `FridgeChef-AI-handoff.zip` → 点击下载按钮或 **Download raw file／下载原始文件** → 解压 → 阅读里面的 README 与交接说明。

如果仓库里是完整源码：点击绿色 **Code → Download ZIP** → 解压 → 找到含 `package.json` 的目录 → 按交接说明安装依赖。[官方下载说明](https://docs.github.com/en/repositories/working-with-files/using-files/downloading-source-code-archives)

公开下载不要求 GitHub 账号。下载完成后仍需安装 Node.js、pnpm 和依赖，完整网站不是双击 HTML 就能启动。
对只放交接 ZIP 的仓库点击 **Code → Download ZIP**，会得到外层 ZIP，里面的交接 ZIP 还要再解压一次。

## 同学如何交回修改

最简单：把修改后的源码打包交回，附上 API 环境变量名、配置方法和测试结果，同样不带真实密钥、依赖、缓存和构建产物。

长期协作：完整源码仓库可以 **Fork → 修改 → Pull request**。拥有者确认并合并，再部署到 Cloudflare。若希望同学直接提交，再单独邀请为协作者。

同学不需要拥有者的 Cloudflare 密码，部署和线上 Secret 由拥有者负责。
