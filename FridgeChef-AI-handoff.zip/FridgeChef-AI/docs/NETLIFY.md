# Netlify 部署

專案保留 Sites 的 Vinext 建置，另外使用 Next.js 建置部署到 Netlify。
不要上傳原本的 `dist`：它是 Cloudflare Worker 輸出，不是 Netlify 網站。

## 完整網站

1. 安裝 Node.js 24、pnpm 11.25，執行 `pnpm install`。
2. 在專案根目錄執行 `pnpm dlx netlify-cli login`，於瀏覽器登入授權。
3. 執行 `pnpm dlx netlify-cli deploy --prod`，選自己的團隊及新網站。CLI 會讀取 `netlify.toml`，打包前端和 API。
4. 在網站控制台的 Environment variables 設定 `SILICONFLOW_API_KEY`，只供 Functions 使用，標記為 Secret。
5. 可另外設定 `SILICONFLOW_VISION_MODEL=Qwen/Qwen3-VL-8B-Instruct` 和 `SILICONFLOW_RECIPE_MODEL=Qwen/Qwen3-8B`。
6. 設定環境變數後重新部署，再實測照片辨識和食譜生成。

不要把金鑰放進聊天、Git、`netlify.toml`、`NEXT_PUBLIC_*` 或公開壓縮檔。
`.env.local` 僅供本機使用，不會自動成為 Netlify 的函式環境變數。

## 檔案

核心：`app/`、`components/kitchen.tsx`、`lib/food.ts`、`lib/ai.ts`、`public/`。
設定：`package.json`、`pnpm-lock.yaml`、`pnpm-workspace.yaml`、`next.config.ts`、`tsconfig.json`、`postcss.config.mjs`、`netlify.toml`、`scripts/build-netlify.mjs`。
現有專案保留 Sites 模組，連接整個原始碼倉庫較省事，不要省略其他檔案引用的模組。
不要上傳 `node_modules/`、`.env.local`、`.git/`、`.wrangler/`、`.sites-runtime/`、`artifacts/`。

## 限制

- Netlify 同步函式上限目前為 60 秒，本站在 Netlify 的 AI 請求使用 50 秒逾時。
- 試用配額僅保存在執行個體記憶體，不是全站持久化限額；留意代金券消耗。
- Netlify 是境外託管，不能保證中國大陸免 VPN 存取。請用實際展示網路測試。
- 官方文件：https://docs.netlify.com/build/frameworks/framework-setup-guides/nextjs/overview/
- 官方 CLI：https://cli.netlify.com/commands/deploy/
