import Kitchen from "@/components/kitchen";
export default function Home() { return <Kitchen />; }
