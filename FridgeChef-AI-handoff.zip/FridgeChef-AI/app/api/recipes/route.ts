import { guarded, readBody, recommend } from "@/lib/ai";
export async function POST(request: Request) { return guarded(request, async () => recommend(await readBody(request, 32_000))); }
