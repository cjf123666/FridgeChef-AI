import { guarded, readBody, recognize } from "@/lib/ai";
export async function POST(request: Request) { return guarded(request, async () => recognize(await readBody(request))); }
