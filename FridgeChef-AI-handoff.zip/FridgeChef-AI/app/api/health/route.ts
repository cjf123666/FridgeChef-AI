export async function GET() { return Response.json({ configured: Boolean(process.env.SILICONFLOW_API_KEY), provider: "SiliconFlow" }, { headers: { "Cache-Control": "no-store" } }); }
