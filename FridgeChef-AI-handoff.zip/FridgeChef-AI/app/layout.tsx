import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "FridgeChef AI｜冰箱料理魔法師",
  description: "把冰箱裡的食材，變成今天的三道中式家常料理。",
  icons: {
    icon: "/favicon.svg",
    shortcut: "/favicon.svg",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="zh-Hant">
      <body className="antialiased">{children}</body>
    </html>
  );
}
