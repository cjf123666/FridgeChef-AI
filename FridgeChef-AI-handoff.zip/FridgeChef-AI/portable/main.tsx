import { createRoot } from "react-dom/client";
import Kitchen from "../components/kitchen";
import sampleImage from "../public/ingredients.png";

// The portable build uses esbuild's dataurl loader, not Next's image metadata.
createRoot(document.getElementById("root")!).render(<Kitchen offline sampleImage={sampleImage as unknown as string} />);
