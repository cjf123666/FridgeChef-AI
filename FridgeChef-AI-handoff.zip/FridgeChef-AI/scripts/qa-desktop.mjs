import assert from "node:assert/strict";
import { mkdir } from "node:fs/promises";
const { chromium } = await import(process.env.PLAYWRIGHT_MODULE || "playwright");
import { sampleIngredients, sampleRecipes } from "../lib/food.ts";

await mkdir("artifacts", { recursive: true });
const browser = await chromium.launch({ channel: "msedge", headless: true });
const page = await browser.newPage({ viewport: { width: 1440, height: 1000 } });
const errors = [];
page.on("pageerror", e => errors.push(e.message));
try {
  await page.goto(process.env.QA_BASE_URL || "http://127.0.0.1:5173/");
  await page.getByRole("heading", { name: "今天，冰箱裡有什麼？" }).waitFor();
  await page.getByText("AI 尚待啟用 · 目前可使用範例體驗", { exact: true }).waitFor();
  await page.waitForFunction(() => [...document.images].every(i => i.complete && i.naturalWidth > 0));
  assert.equal(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth), true);
  await page.screenshot({ path: "artifacts/desktop-home.png", fullPage: true });
  await page.getByRole("button", { name: "範例體驗", exact: true }).click();
  await page.getByLabel("食材 1 名稱").fill("");
  await page.getByRole("button", { name: "確認食材", exact: true }).click();
  await page.locator(".message.error[role=alert]").waitFor();
  await page.getByLabel("食材 1 名稱").fill("番茄");
  await page.getByLabel("食用油", { exact: true }).check();
  await page.getByRole("button", { name: "確認食材", exact: true }).click();
  await page.getByRole("button", { name: "查看範例食譜", exact: true }).click();
  await page.getByRole("heading", { name: "為你準備的三道家常菜" }).waitFor();
  assert.equal(await page.locator(".recipe-card").count(), 3);
  await page.screenshot({ path: "artifacts/desktop-recipes.png", fullPage: true });
  await page.locator(".recipe-card").filter({ hasText: "番茄炒蛋" }).getByRole("button", { name: "查看做法" }).click();
  await page.getByRole("heading", { name: "需要的材料" }).waitFor();
  for (let i = 1; i <= 4; i++) await page.getByRole("button", { name: `步驟 ${i} 未完成`, exact: true }).click();
  await page.getByText("料理完成，開飯囉！", { exact: true }).waitFor();
  const downloadEvent = page.waitForEvent("download");
  await page.getByRole("button", { name: "下載這道食譜", exact: true }).click();
  assert.equal((await downloadEvent).suggestedFilename(), "番茄炒蛋.txt");
  await page.getByRole("button", { name: "FridgeChef AI 首頁", exact: true }).click();
  await page.getByLabel("選擇食材照片").setInputFiles("public/ingredients.png");
  await page.getByRole("button", { name: "辨識食材", exact: true }).waitFor();
  await page.getByRole("button", { name: "辨識食材", exact: true }).click();
  await page.locator(".message.error[role=alert]").waitFor();
  assert.match(await page.locator(".message.error[role=alert]").innerText(), /尚未啟用/);

  // Mocked provider responses verify the UI contract without claiming a live call.
  await page.route("**/api/recognize", route => route.fulfill({ json: { ingredients: sampleIngredients } }));
  await page.getByRole("button", { name: "辨識食材", exact: true }).click();
  await page.getByRole("heading", { name: "確認你的冰箱食材" }).waitFor();
  assert.equal(await page.getByLabel("食材 1 名稱").inputValue(), "番茄");
  await page.getByRole("button", { name: "確認食材", exact: true }).click();
  await page.route("**/api/recipes", async route => {
    const input = route.request().postDataJSON();
    assert.equal(input.preferences.minutes, 30);
    assert.equal(input.ingredients.length, 5);
    await route.fulfill({ json: { recipes: sampleRecipes.slice(0, 3), source: "ai" } });
  });
  await page.getByRole("button", { name: "生成我的食譜", exact: true }).click();
  await page.getByRole("heading", { name: "為你準備的三道家常菜" }).waitFor();
  assert.equal(await page.locator(".recipe-card").count(), 3);
  await page.setViewportSize({ width: 1100, height: 800 });
  assert.equal(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth), true);
  assert.deepEqual(errors, []);
  console.log("Desktop QA passed: images, ingredient edits, validation, preferences, three recipes, cooking checklist, download, missing-key error, mocked AI contracts, 1440/1100px layouts.");
} catch (error) { console.log("Page errors:", errors); await page.screenshot({ path: "artifacts/desktop-failure.png", fullPage: true }); throw error; }
finally { await browser.close(); }
