import { readFile, readdir, mkdir, writeFile } from "node:fs/promises";
import path from "node:path";
import { fileURLToPath, pathToFileURL } from "node:url";

const root = fileURLToPath(new URL("../", import.meta.url));
const store = path.join(root, "node_modules/.pnpm");
const esbuildFolder = (await readdir(store)).find(name => name.startsWith("esbuild@0.28."));
if (!esbuildFolder) throw new Error("Install project dependencies first.");
const { build } = await import(pathToFileURL(path.join(store, esbuildFolder, "node_modules/esbuild/lib/main.js")).href);
const result = await build({
  absWorkingDir: root,
  entryPoints: ["portable/main.tsx"],
  bundle: true,
  minify: true,
  platform: "browser",
  format: "iife",
  target: "es2020",
  jsx: "automatic",
  define: { "process.env.NODE_ENV": '"production"' },
  loader: { ".png": "dataurl" },
  write: false,
});
const cssDirectory = path.join(root, ".next/static/css");
const cssFiles = (await readdir(cssDirectory)).filter(name => name.endsWith(".css"));
if (!cssFiles.length) throw new Error("Run the Netlify build first to compile styles.");
const css = (await Promise.all(cssFiles.map(name => readFile(path.join(cssDirectory, name), "utf8")))).join("\n");
const js = result.outputFiles[0].text.replace(/<\/script/gi, "<\\/script");
const html = `<!doctype html><html lang="zh-Hant"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>FridgeChef AI | 冰箱料理魔法師 - 離線展示版</title><style>${css.replace(/<\/style/gi, "<\\/style")}</style></head><body><div id="root"></div><script>${js}</script></body></html>`;
const output = path.join(root, "artifacts/FridgeChef-AI-offline.html");
await mkdir(path.dirname(output), { recursive: true });
await writeFile(output, html, "utf8");
console.log(output);
