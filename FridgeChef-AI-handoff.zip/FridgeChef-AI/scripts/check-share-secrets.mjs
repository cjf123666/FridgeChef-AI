import { readFile, readdir } from "node:fs/promises";
import path from "node:path";
import { fileURLToPath } from "node:url";

const projectRoot = fileURLToPath(new URL("../", import.meta.url));
const textExtensions = new Set([".ts", ".tsx", ".mts", ".mjs", ".js", ".json", ".yaml", ".yml", ".md", ".css", ".html", ".toml", ".sh", ".txt", ".example"]);

export async function checkShareSecrets(targetDirectory) {
  let environment = "";
  try { environment = await readFile(path.join(projectRoot, ".env.local"), "utf8"); }
  catch (error) { if (error.code !== "ENOENT") throw error; }
  const secretValues = environment.split(/\r?\n/).flatMap(line => {
    const match = line.match(/^\s*([A-Z_][A-Z0-9_]*(?:KEY|TOKEN|SECRET|PASSWORD)[A-Z0-9_]*)\s*=\s*(.*?)\s*$/);
    if (!match) return [];
    const value = match[2].replace(/^["']|["']$/g, "");
    return value.length >= 12 ? [value] : [];
  });
  const violations = [];
  let scanned = 0;
  async function walk(directory) {
    for (const entry of await readdir(directory, { withFileTypes: true })) {
      const absolute = path.join(directory, entry.name);
      const relative = path.relative(targetDirectory, absolute).split(path.sep).join("/");
      if (entry.isSymbolicLink()) throw new Error(`Share scan refuses symbolic link: ${relative}`);
      if (entry.isDirectory()) { await walk(absolute); continue; }
      if (/^\.env/.test(entry.name) && entry.name !== ".env.example") violations.push(relative);
      if (!textExtensions.has(path.extname(entry.name)) && !entry.name.startsWith(".")) continue;
      const content = await readFile(absolute, "utf8");
      scanned++;
      if (secretValues.some(value => content.includes(value)) || /-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----/.test(content) || /\bsk-[A-Za-z0-9_-]{24,}\b/.test(content)) violations.push(relative);
    }
  }
  await walk(targetDirectory);
  if (violations.length) throw new Error(`Possible secret in these files (values withheld): ${[...new Set(violations)].join(", ")}`);
  return scanned;
}

if (process.argv[1] && path.resolve(process.argv[1]) === fileURLToPath(import.meta.url)) {
  const target = process.argv[2];
  if (!target) throw new Error("Usage: node scripts/check-share-secrets.mjs <directory>");
  const count = await checkShareSecrets(path.resolve(target));
  console.log(`Secret scan passed for ${count} text files. Secret values were not printed.`);
}
