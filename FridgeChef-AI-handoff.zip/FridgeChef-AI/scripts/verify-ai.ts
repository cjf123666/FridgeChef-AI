import assert from "node:assert/strict";
import { test } from "node:test";
import { guarded, recognize, recommend, readBody } from "../lib/ai";
import { allowed, missing, sampleIngredients, sampleRecipes, demoRecipes, type Preferences } from "../lib/food";
const preferences: Preferences = { minutes: 30, servings: 2, taste: "家常", diet: "不限", exclusions: [] };
test("food constraints and missing pantry are respected", () => {
  assert.equal(allowed(sampleRecipes[0], {...preferences, exclusions: ["雞蛋"]}), false);
  assert.equal(allowed(sampleRecipes[1], {...preferences, exclusions: ["大豆"]}), false);
  assert.equal(allowed(sampleRecipes[0], {...preferences, diet: "全素"}), false);
  assert.equal(allowed(sampleRecipes[1], {...preferences, minutes: 15}), false);
  assert.deepEqual(missing(sampleRecipes[0], sampleIngredients).map(x => x.name), ["食用油", "鹽"]);
  assert.equal(demoRecipes(sampleIngredients, preferences).length, 3);
  assert.equal(demoRecipes(sampleIngredients, {...preferences, diet: "全素"}).length, 3);
  assert.deepEqual(demoRecipes(sampleIngredients, {...preferences, taste: "香辣"}), []);
});
test("bounded body parser rejects invalid and oversized input", async () => {
  await assert.rejects(() => readBody(new Request("https://test.local/api", { method: "POST", headers: {"content-type":"application/json"}, body: "not-json" })), /資料格式/);
  await assert.rejects(() => readBody(new Request("https://test.local/api", { method: "POST", headers: {"content-type":"application/json"}, body: '{"x":"long"}' }), 3), /照片太大/);
});
test("missing credentials and cross-origin requests fail without provider calls", async () => {
  delete process.env.SILICONFLOW_API_KEY;
  let called = false;
  const response = await guarded(new Request("https://test.local/api"), async () => { called = true; });
  assert.equal(response.status, 503); assert.equal(called, false);
  const blocked = await guarded(new Request("https://test.local/api", { headers: { origin: "https://other.local" } }), async () => ({}));
  assert.equal(blocked.status, 403);
});
test("mocked SiliconFlow contracts, output validation and provider errors", async () => {
  const original = globalThis.fetch;
  process.env.SILICONFLOW_API_KEY = "test-key-only";
  try {
    globalThis.fetch = async (_url, options) => {
      const request = JSON.parse(String(options?.body));
      assert.equal((options?.headers as Record<string,string>).Authorization, "Bearer test-key-only");
      if (request.model === "Qwen/Qwen3-8B") assert.equal(request.enable_thinking, false);
      if (request.model === "Qwen/Qwen3-VL-8B-Instruct") { assert.match(request.messages[1].content[0].image_url.url, /^data:image\/jpeg/); return Response.json({ choices:[{message:{content: JSON.stringify({ingredients:sampleIngredients})}}] }); }
      assert.equal(request.model, "Qwen/Qwen3-8B");
      return Response.json({choices:[{message:{content: JSON.stringify({recipes:sampleRecipes.slice(0,3)})}}]});
    };
    assert.equal((await recognize({image:"data:image/jpeg;base64,aGVsbG8="})).ingredients.length, 5);
    assert.equal((await recommend({ ingredients:sampleIngredients, preferences })).recipes.length, 3);
    await assert.rejects(() => recommend({ ingredients:sampleIngredients, preferences:{...preferences, exclusions:["雞蛋"]} }), /忌口條件/);
    globalThis.fetch = async () => Response.json({}, {status:429});
    await assert.rejects(() => recognize({image:"data:image/jpeg;base64,aGVsbG8="}), /忙碌/);
    globalThis.fetch = async () => Response.json({choices:[{message:{content:"bad JSON"}}]});
    await assert.rejects(() => recommend({ ingredients:sampleIngredients, preferences }), /格式不完整/);
  } finally { globalThis.fetch = original; delete process.env.SILICONFLOW_API_KEY; }
});
test("Netlify runtime trusts the request host and keeps IP limits separate", async () => {
  const previousSite = process.env.SITE_ID;
  process.env.SITE_ID = "test-netlify-site";
  process.env.SILICONFLOW_API_KEY = "test-key-only";
  const makeRequest = (ip: string, origin = "https://kitchen.netlify.app") => new Request("http://localhost/api", {
    headers: { host: "kitchen.netlify.app", origin, "x-nf-client-connection-ip": ip },
  });
  try {
    for (let i = 0; i < 12; i++) assert.equal((await guarded(makeRequest("test-ip-a"), async () => ({}))).status, 200);
    assert.equal((await guarded(makeRequest("test-ip-a"), async () => ({}))).status, 429);
    assert.equal((await guarded(makeRequest("test-ip-b"), async () => ({}))).status, 200);
    assert.equal((await guarded(makeRequest("test-ip-b", "https://other.local"), async () => ({}))).status, 403);
  } finally {
    delete process.env.SILICONFLOW_API_KEY;
    if (previousSite === undefined) delete process.env.SITE_ID; else process.env.SITE_ID = previousSite;
  }
});
