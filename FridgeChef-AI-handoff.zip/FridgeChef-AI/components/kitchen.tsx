"use client";

import { useEffect, useRef, useState } from "react";
import { z } from "zod";
import { ArrowRight, ArrowLeft, Camera, Check, ChefHat, Clock3, Download, Flame, Leaf, LoaderCircle, Minus, Plus, Refrigerator, RotateCcw, ShoppingBasket, Sparkles, Trash2, Upload, Users, X, ImagePlus } from "lucide-react";
import { Ingredient, Preferences, Recipe, ingredientSchema, recipeSchema, sampleIngredients, pantryNames, demoRecipes, missing, sameFood } from "@/lib/food";

type Stage = "upload" | "ingredients" | "preferences" | "recipes" | "detail";
const steps = ["上傳食材", "確認食材", "料理偏好", "今日食譜"];
const defaultPreferences: Preferences = { minutes: 30, servings: 2, taste: "家常", diet: "不限", exclusions: [] };

async function post(path: string, body: unknown) {
  const response = await fetch(path, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(body), signal: AbortSignal.timeout(90_000) });
  let data; try { data = await response.json(); } catch { throw new Error("服務暫時無法回應，請重試。"); }
  if (!response.ok) throw new Error(z.object({ error: z.string() }).safeParse(data).data?.error || "請求未完成，請重試。");
  return data;
}
async function imageData(file: File): Promise<string> {
  if (!["image/jpeg", "image/png", "image/webp"].includes(file.type)) throw new Error("請選擇 JPG、PNG 或 WebP 圖片；HEIC 請先轉成 JPG。");
  if (file.size > 10 * 1024 * 1024) throw new Error("照片需小於 10 MB。");
  const bitmap = await createImageBitmap(file); const scale = Math.min(1, 1600 / Math.max(bitmap.width, bitmap.height));
  const canvas = document.createElement("canvas"); canvas.width = Math.round(bitmap.width * scale); canvas.height = Math.round(bitmap.height * scale);
  const ctx = canvas.getContext("2d"); if (!ctx) throw new Error("無法讀取照片，請換一張重試。");
  ctx.fillStyle = "white"; ctx.fillRect(0, 0, canvas.width, canvas.height); ctx.drawImage(bitmap, 0, 0, canvas.width, canvas.height); bitmap.close();
  const result = canvas.toDataURL("image/jpeg", 0.82); if (result.length > 5_600_000) throw new Error("照片仍然太大，請換一張較小的照片。"); return result;
}

export default function Kitchen({ offline = false, sampleImage = "/ingredients.png" }: { offline?: boolean; sampleImage?: string } = {}) {
  const [stage, setStage] = useState<Stage>("upload"); const [image, setImage] = useState(""); const [filename, setFilename] = useState("");
  const [items, setItems] = useState<Ingredient[]>([]); const [preferences, setPreferences] = useState<Preferences>(defaultPreferences);
  const [pantry, setPantry] = useState<string[]>([]); const [recipes, setRecipes] = useState<Recipe[]>([]); const [selected, setSelected] = useState(0);
  const [demo, setDemo] = useState(false); const [busy, setBusy] = useState(""); const [error, setError] = useState(""); const [notice, setNotice] = useState("");
  const [configured, setConfigured] = useState<boolean | null>(offline ? false : null); const [dragging, setDragging] = useState(false); const [custom, setCustom] = useState("");
  const [completed, setCompleted] = useState<number[]>([]); const [checked, setChecked] = useState<string[]>([]);
  const fileRef = useRef<HTMLInputElement>(null); const cameraRef = useRef<HTMLInputElement>(null); const titleRef = useRef<HTMLHeadingElement>(null);
  useEffect(() => { if (offline) return; fetch("/api/health").then(r => r.json()).then(d => setConfigured(z.object({ configured: z.boolean() }).parse(d).configured)).catch(() => setConfigured(null)); }, [offline]);
  useEffect(() => { if (stage !== "upload") { titleRef.current?.focus({ preventScroll: true }); window.scrollTo({ top: 0, behavior: "smooth" }); } }, [stage]);
  const step = stage === "upload" ? 0 : stage === "ingredients" ? 1 : stage === "preferences" ? 2 : 3;
  const allItems = [...items, ...pantry.filter(name => !items.some(i => sameFood(i.name, name))).map(name => ({ name, quantity: "家中常備", confidence: "high" as const }))];
  const recipe = recipes[selected];
  function go(next: Stage) { setError(""); setNotice(""); if (next === "ingredients" || next === "preferences") setRecipes([]); setStage(next); }
  function reset() { setImage(""); setFilename(""); setItems([]); setRecipes([]); setPantry([]); setPreferences(defaultPreferences); setDemo(false); setCompleted([]); setChecked([]); go("upload"); }
  async function choose(file?: File) {
    if (!file || busy) return; setBusy("正在準備照片"); setError("");
    try { setImage(await imageData(file)); setFilename(file.name); setDemo(false); setItems([]); setRecipes([]); } catch(e) { setError(e instanceof Error ? e.message : "無法讀取照片。"); } finally { setBusy(""); }
  }
  async function recognize() {
    if (!image || busy) return; if (offline) { setError("離線展示版不會呼叫 AI。可使用範例體驗，或手動填寫食材。"); return; } setBusy("AI 正在辨識食材"); setError("");
    try { const data = z.object({ ingredients: z.array(ingredientSchema) }).parse(await post("/api/recognize", { image })); setItems(data.ingredients); setRecipes([]); go("ingredients"); if (!data.ingredients.length) setNotice("這張照片沒有辨識到食材，可以重新拍攝或手動新增。"); }
    catch(e) { setError(e instanceof Error ? e.message : "辨識未完成，請重試。"); } finally { setBusy(""); }
  }
  function sample() { setDemo(true); setImage(sampleImage); setFilename("範例食材照片"); setItems(sampleIngredients.map(i => ({...i}))); setRecipes([]); setPreferences(defaultPreferences); setPantry([]); go("ingredients"); }
  function manual() { setDemo(false); setItems([{ name: "", quantity: "", confidence: "high" }]); setRecipes([]); go("ingredients"); }
  function changeItem(index: number, field: "name" | "quantity", value: string) { setItems(items.map((i, n) => n === index ? { ...i, [field]: value, confidence: "high" } : i)); setRecipes([]); }
  function confirmItems() {
    const clean = items.map(i => ({ ...i, name: i.name.trim(), quantity: i.quantity.trim() }));
    if (!clean.length || clean.some(i => !i.name)) { setError("請填寫每一項食材名稱，並保留至少一項食材。"); return; }
    if (new Set(clean.map(i => i.name)).size !== clean.length) { setError("有重複的食材，請合併數量後再繼續。"); return; }
    setItems(clean); go("preferences");
  }
  function toggleExclusion(name: string) { setPreferences(p => ({ ...p, exclusions: p.exclusions.includes(name) ? p.exclusions.filter(x => x !== name) : p.exclusions.length < 12 ? [...p.exclusions, name] : p.exclusions })); }
  async function generate() {
    if (busy) return; if (offline && !demo) { setError("離線展示版只提供預設範例食譜，無法即時生成。請回首頁使用範例體驗。"); return; } setBusy(demo ? "正在整理範例食譜" : "AI 正在搭配三道家常菜"); setError("");
    try {
      let results: Recipe[];
      if (demo) { results = demoRecipes(items, preferences); if (results.length !== 3) throw new Error("範例資料無法滿足這組條件。請使用 2 人份、清淡或家常口味，並保留足夠食材；任意食材與口味需啟用 AI 後生成。"); }
      else { results = z.object({ recipes: z.array(recipeSchema).length(3) }).parse(await post("/api/recipes", { ingredients: allItems, preferences })).recipes; }
      setRecipes(results); setChecked([]); setCompleted([]); go("recipes");
    } catch(e) { setError(e instanceof Error ? e.message : "推薦未完成，請重試。"); } finally { setBusy(""); }
  }
  function download(r: Recipe) {
    const text = `${r.title}\n${demo ? "預設範例食譜" : "AI 生成食譜"}｜${r.minutes} 分鐘｜${preferences.servings} 人份\n\n${r.description}\n\n材料\n${r.ingredients.map(i => `${i.name}：${i.quantity}${missing(r, allItems).some(x => x.name === i.name) ? "（待補）" : ""}`).join("\n")}\n\n步驟\n${r.steps.map((s, i) => `${i + 1}. ${s}`).join("\n")}\n\n小訣竅：${r.tip}\n\n已列入冰箱的材料仍需核對實際份量。`;
    const url = URL.createObjectURL(new Blob(["\uFEFF", text], { type: "text/plain;charset=utf-8" })); const a = document.createElement("a"); a.href = url; a.download = `${r.title}.txt`; a.click(); setTimeout(() => URL.revokeObjectURL(url), 1000);
  }

  return <div className="app-shell">
    <header className="site-header"><div className="header-inner">
      <button className="brand" onClick={reset} disabled={Boolean(busy)} aria-label="FridgeChef AI 首頁"><span className="brand-mark"><ChefHat size={25}/></span><span><strong>FridgeChef <span>AI</span></strong><small>冰箱料理魔法師</small></span></button>
      <nav aria-label="主選單"><button className={stage !== "recipes" && stage !== "detail" ? "nav-active" : ""} disabled={Boolean(busy)} onClick={() => go(items.length ? "ingredients" : "upload")}><Refrigerator size={17}/>我的冰箱</button><button disabled={!recipes.length || Boolean(busy)} onClick={() => go("recipes")} className={step === 3 ? "nav-active" : ""}><ShoppingBasket size={17}/>今日食譜</button></nav>
      <span className="header-note"><Leaf size={15}/>好好吃飯，不浪費</span>
    </div></header>
    <main aria-busy={Boolean(busy)}>
      <div className="flow-bar" aria-label="料理進度">{steps.map((label, i) => <div className={`flow-step ${i === step ? "current" : i < step ? "finished" : ""}`} key={label} aria-current={i === step ? "step" : undefined}><span>{i < step ? <Check size={14}/> : `0${i+1}`}</span><b>{label}</b>{i < 3 && <div className="flow-line"/>}</div>)}</div>
      {(demo || configured === false) && <div className={`mode-note ${demo ? "sample-mode" : ""}`}><Sparkles size={15}/><span>{demo ? "範例體驗 · 使用預設食材與食譜，非即時 AI 結果" : offline ? "離線展示版 · 範例食譜非即時 AI 結果" : "AI 尚待啟用 · 目前可使用範例體驗"}</span></div>}
      {stage === "upload" ? <>
        <div className="intro"><span className="eyebrow"><span/>從冰箱開始的好料理</span><h1 ref={titleRef}>今天，冰箱裡有什麼？</h1><p>把手邊的食材，變成一桌剛剛好的家常菜。</p></div>
        <div className="upload-workspace">
          <section className="upload-section"><div className="section-label"><span className="small-number">01</span><h2>放入你的食材照片</h2><span className="tiny-label">從一張照片開始</span></div>
            <input ref={fileRef} className="sr-only" type="file" accept="image/jpeg,image/png,image/webp" onChange={e => { void choose(e.target.files?.[0]); e.target.value = ""; }} aria-label="選擇食材照片"/>
            <input ref={cameraRef} className="sr-only" type="file" accept="image/*" capture="environment" onChange={e => { void choose(e.target.files?.[0]); e.target.value = ""; }} aria-label="拍攝食材照片"/>
            <div className={`drop-zone ${dragging ? "dragging" : ""} ${image ? "has-image" : ""}`} onDragOver={e => { e.preventDefault(); setDragging(true); }} onDragLeave={() => setDragging(false)} onDrop={e => { e.preventDefault(); setDragging(false); void choose(e.dataTransfer.files[0]); }}>
              {image ? <><img src={image} alt="已選擇的食材照片" className="uploaded-image"/><div className="photo-caption"><span>{filename}</span><button className="icon-button light" title="移除照片" aria-label="移除照片" disabled={Boolean(busy)} onClick={() => { setImage(""); setFilename(""); }}><X size={18}/></button></div></> : <><div className="upload-symbol"><ImagePlus size={37} strokeWidth={1.3}/></div><h3>給食材拍張合照</h3><p>拖曳照片到這裡，或從相簿選擇</p><button className="primary" disabled={Boolean(busy)} onClick={() => fileRef.current?.click()}><Upload size={17}/>選擇食材照片</button><span className="file-hint">JPG、PNG、WebP · 最大 10 MB</span></>}
            </div>
            <div className="upload-actions">{image ? <><button className="secondary" disabled={Boolean(busy)} onClick={() => fileRef.current?.click()}><RotateCcw size={16}/>換一張</button><button className="primary" onClick={() => void recognize()} disabled={Boolean(busy)}>{busy ? <LoaderCircle className="spin" size={17}/> : <Sparkles size={17}/>}辨識食材<ArrowRight size={17}/></button></> : <><button className="text-button" disabled={Boolean(busy)} onClick={() => cameraRef.current?.click()}><Camera size={17}/>直接拍照</button><span className="action-divider"/><button className="text-button" disabled={Boolean(busy)} onClick={manual}>手動新增食材<ArrowRight size={15}/></button></>}</div>
            <div className="privacy-note"><Check size={14}/><span>照片僅用於本次辨識，不儲存至相簿。</span></div>
          </section>
          <aside className="inspiration"><div className="inspiration-image"><img src={sampleImage} alt="番茄、雞蛋、青江菜、豆腐與香菇的食材範例"/><span className="image-tag"><Leaf size={14}/>平凡食材，也有好滋味</span></div><div className="inspiration-body"><span className="eyebrow">先試試這一份冰箱</span><h2>一點靈感，剛好開飯。</h2><p>番茄、雞蛋、青菜、豆腐與香菇</p><div className="sample-footer"><span>5 種食材 <span className="dot-separator">·</span> 中式家常味</span><button className="text-button" onClick={sample} disabled={Boolean(busy)}>範例體驗<ArrowRight size={17}/></button></div></div></aside>
        </div>
        <div className="bottom-strip"><div><span className="strip-icon"><Refrigerator size={21}/></span><span><b>用好冰箱裡的每一樣</b><small>從現有食材，找到今天的菜單</small></span></div><div><span className="strip-icon peach"><Clock3 size={21}/></span><span><b>配合你的下廚時間</b><small>15 分鐘快手菜，或慢慢煮一餐</small></span></div><div><span className="strip-icon lilac"><ChefHat size={21}/></span><span><b>熟悉的中式家常味</b><small>清淡、下飯，也照顧你的忌口</small></span></div></div>
      </> : <>
        <div className="page-heading"><div><span className="eyebrow">{step === 1 ? "看看手邊的好食材" : step === 2 ? "照顧你的每一種喜好" : "今天也要好好吃飯"}</span><h1 ref={titleRef} tabIndex={-1}>{stage === "ingredients" ? "確認你的冰箱食材" : stage === "preferences" ? "這一餐，想怎麼吃？" : stage === "recipes" ? "為你準備的三道家常菜" : recipe?.title}</h1><p>{stage === "ingredients" ? "確認名稱與實際份量，再開始搭配料理。" : stage === "preferences" ? "選好時間、口味和忌口，讓這餐更合心意。" : stage === "recipes" ? `${preferences.servings} 人份 · ${preferences.taste}口味 · 每道 ${preferences.minutes} 分鐘內` : recipe?.description}</p></div><button className="text-button" disabled={Boolean(busy)} onClick={() => go(stage === "ingredients" ? "upload" : stage === "preferences" ? "ingredients" : stage === "detail" ? "recipes" : "preferences")}><ArrowLeft size={16}/>{stage === "detail" ? "回到三道食譜" : "上一步"}</button></div>
        {stage === "ingredients" && <div className="confirm-layout"><section className="ingredient-editor"><div className="section-label"><h2>食材清單</h2><span className="count-label">{items.length} 項食材</span></div>{!items.length && <div className="empty-state"><ShoppingBasket size={32}/><p>還沒有食材，新增一項開始吧。</p></div>}
          <div className="ingredient-table"><div className="ingredient-table-head"><span>食材名稱</span><span>現有份量</span><span/></div>{items.map((i, n) => <div className="ingredient-row" key={n}><div><input aria-label={`食材 ${n+1} 名稱`} value={i.name} maxLength={30} placeholder="例如：番茄" onChange={e => changeItem(n, "name", e.target.value)}/>{i.confidence !== "high" && !demo && <small className="uncertain">{i.confidence === "low" ? "辨識不確定，請確認" : "請確認名稱與份量"}</small>}</div><input aria-label={`食材 ${n+1} 份量`} value={i.quantity} maxLength={30} placeholder="例如：2 顆" onChange={e => changeItem(n, "quantity", e.target.value)}/><button className="icon-button" title={`刪除${i.name || "食材"}`} aria-label={`刪除食材 ${n+1}`} onClick={() => setItems(items.filter((_, index) => index !== n))}><Trash2 size={17}/></button></div>)}</div>
          <button className="text-button add-item" disabled={items.length >= 20} onClick={() => setItems([...items, { name: "", quantity: "", confidence: "high" }])}><Plus size={18}/>新增食材</button>
          <div className="pantry-section"><h3>家中常備調味料</h3><div className="checkbox-options">{pantryNames.map(name => <label key={name}><input type="checkbox" checked={pantry.includes(name)} onChange={e => setPantry(e.target.checked ? [...pantry, name] : pantry.filter(x => x !== name))}/>{name}</label>)}</div></div>
          <div className="form-footer"><span>數量以實際確認為準</span><button className="primary" onClick={confirmItems}>確認食材<ArrowRight size={17}/></button></div></section><aside className="photo-reference">{image ? <img src={image} alt="本次食材照片"/> : <div className="empty-photo"><Refrigerator size={48}/><span>手動整理的冰箱</span></div>}<div><span className="eyebrow">{demo ? "範例食材" : "這次的食材"}</span><h3>一份食材，更多可能。</h3><p>{demo ? "這份清單是預設範例，可修改後繼續體驗。" : "AI 辨識可能有誤，請以實物確認食材及新鮮度。"}</p></div></aside></div>}
        {stage === "preferences" && <div className="preferences-layout"><section className="preference-form"><fieldset><legend><Clock3 size={19}/>料理時間</legend><div className="segmented">{[15,30,45,60].map(minutes => <button key={minutes} aria-pressed={preferences.minutes === minutes} onClick={() => setPreferences({...preferences, minutes})}>{minutes} 分鐘</button>)}</div></fieldset>
          <fieldset><legend><Users size={19}/>用餐人數</legend><div className="servings-control"><button className="icon-button" aria-label="減少人數" title="減少人數" disabled={preferences.servings === 1} onClick={() => setPreferences({...preferences, servings: preferences.servings-1})}><Minus size={18}/></button><span>{preferences.servings}<small>人份</small></span><button className="icon-button" aria-label="增加人數" title="增加人數" disabled={preferences.servings === 6} onClick={() => setPreferences({...preferences, servings: preferences.servings+1})}><Plus size={18}/></button></div></fieldset>
          <fieldset><legend><Flame size={19}/>今天的口味</legend><div className="taste-options">{(["清淡", "家常", "微辣", "香辣"] as const).map((taste, n) => <button key={taste} aria-pressed={preferences.taste === taste} onClick={() => setPreferences({...preferences, taste})}>{n < 2 ? <Leaf size={20}/> : <Flame size={20}/>}<span>{taste}</span><small>{["原味清爽", "熟悉下飯", "一點辣香", "辣得過癮"][n]}</small></button>)}</div></fieldset>
          <fieldset><legend><Leaf size={19}/>飲食選擇</legend><div className="segmented">{(["不限","蛋奶素","全素"] as const).map(diet => <button key={diet} aria-pressed={preferences.diet === diet} onClick={() => setPreferences({...preferences, diet})}>{diet}</button>)}</div></fieldset>
          <fieldset><legend>不吃的食材</legend><div className="exclusion-options">{["雞蛋","牛奶","花生","海鮮","大豆","麩質"].map(name => <label className={preferences.exclusions.includes(name) ? "selected" : ""} key={name}><input type="checkbox" checked={preferences.exclusions.includes(name)} onChange={() => toggleExclusion(name)}/>{name}</label>)}</div><form className="custom-exclusion" onSubmit={e => { e.preventDefault(); const name = custom.trim(); if (name && preferences.exclusions.length < 12 && !preferences.exclusions.includes(name)) { toggleExclusion(name); setCustom(""); } }}><input aria-label="其他忌口" maxLength={20} placeholder="其他忌口，例如香菜" value={custom} onChange={e => setCustom(e.target.value)}/><button className="icon-button" type="submit" title="新增忌口" aria-label="新增忌口" disabled={!custom.trim() || preferences.exclusions.length >= 12}><Plus size={19}/></button></form><div className="custom-chips">{preferences.exclusions.filter(x => !["雞蛋","牛奶","花生","海鮮","大豆","麩質"].includes(x)).map(x => <button key={x} onClick={() => toggleExclusion(x)} title={`移除${x}`}>{x}<X size={13}/></button>)}</div></fieldset>
          <div className="form-footer"><span>中式家常菜 · 每次三道</span><button className="primary" disabled={Boolean(busy)} onClick={() => void generate()}>{busy ? <LoaderCircle size={17} className="spin"/> : <Sparkles size={17}/>} {demo ? "查看範例食譜" : "生成我的食譜"}<ArrowRight size={17}/></button></div></section><aside className="meal-summary"><span className="eyebrow">這次的冰箱</span><h2>{items.length} 種食材，等待開飯。</h2>{image && <img src={image} alt="已確認的食材"/>}<div className="ingredient-tags">{items.map((i,n) => <span key={n}>{i.name}</span>)}</div><button className="text-button" disabled={Boolean(busy)} onClick={() => go("ingredients")}>修改食材<ArrowRight size={15}/></button></aside></div>}
        {stage === "recipes" && <><div className="results-toolbar"><span><Check size={16}/>{demo ? "預設範例菜單" : "根據你的食材與偏好生成"}</span><button className="text-button" onClick={() => go("preferences")}><RotateCcw size={16}/>重新搭配</button></div><div className="recipe-grid">{recipes.map((r,n) => { const need = missing(r, allItems); return <article className="recipe-card" key={r.title}><div className={`recipe-art art-${n}`}><img src={sampleImage} alt="食材示意圖，非料理成品"/><span className="recipe-order">0{n+1}</span><span className="art-caption">食材示意</span></div><div className="recipe-card-body"><div className="recipe-meta"><span><Clock3 size={15}/>{r.minutes} 分鐘</span><span><Users size={15}/>{preferences.servings} 人份</span></div><h2>{r.title}</h2><p>{r.description}</p><div className="needed"><ShoppingBasket size={15}/>{need.length ? `待補 ${need.length} 項：${need.map(i => i.name).join("、")}` : "材料都已列入冰箱"}</div><button className="recipe-open" onClick={() => { setSelected(n); setCompleted([]); go("detail"); }}>查看做法<ArrowRight size={19}/></button></div></article>; })}</div><section className="shopping-list"><div className="section-label"><ShoppingBasket size={21}/><h2>這一餐的補購清單</h2></div><div className="shopping-items">{Array.from(new Set(recipes.flatMap(r => missing(r, allItems).map(i => i.name)))).map(name => <label key={name}><input type="checkbox" checked={checked.includes(name)} onChange={e => setChecked(e.target.checked ? [...checked,name] : checked.filter(x => x !== name))}/><span className={checked.includes(name) ? "done" : ""}>{name}</span></label>)}{recipes.every(r => !missing(r, allItems).length) && <span className="muted">材料都已列入冰箱，請再核對實際份量。</span>}</div></section></>}
        {stage === "detail" && recipe && <div className="detail-layout"><section className="recipe-instructions"><div className="detail-meta"><span><Clock3 size={18}/>{recipe.minutes} 分鐘</span><span><Users size={18}/>{preferences.servings} 人份</span><span><Flame size={18}/>{preferences.taste}</span><button className="icon-button" title="下載食譜" aria-label="下載食譜" onClick={() => download(recipe)}><Download size={19}/></button></div><h2>開始料理</h2><ol className="cooking-steps">{recipe.steps.map((text,n) => <li key={n} className={completed.includes(n) ? "completed" : ""}><button className="step-check" title={completed.includes(n) ? "標示未完成" : "完成此步驟"} aria-label={`步驟 ${n+1} ${completed.includes(n) ? "已完成" : "未完成"}`} aria-pressed={completed.includes(n)} onClick={() => setCompleted(completed.includes(n) ? completed.filter(i => i !== n) : [...completed,n])}>{completed.includes(n) ? <Check size={18}/> : n+1}</button><p>{text}</p></li>)}</ol><div className="cooking-tip"><Sparkles size={20}/><div><h3>料理小訣竅</h3><p>{recipe.tip}</p></div></div>{completed.length === recipe.steps.length && <div className="finished-cooking"><Check size={21}/>料理完成，開飯囉！</div>}</section><aside className="recipe-materials"><h2>需要的材料</h2><ul>{recipe.ingredients.map((i,n) => { const absent = missing(recipe,allItems).some(x => x.name === i.name); return <li key={n}><div><b>{i.name}</b><small>{i.quantity}</small></div><span className={absent ? "missing-tag" : "available-tag"}>{absent ? "待補" : "已列入"}</span></li>; })}</ul><p className="material-note">已列入的食材仍需核對實際份量。過敏者請確認調味料標示。</p><button className="secondary" onClick={() => download(recipe)}><Download size={16}/>下載這道食譜</button></aside></div>}
      </>}
      {busy && <div className="busy-status" role="status"><LoaderCircle className="spin" size={19}/><span>{busy}…</span></div>}
      {error && <div className="message error" role="alert"><span>{error}</span><button className="icon-button" onClick={() => setError("")} aria-label="關閉錯誤訊息" title="關閉"><X size={17}/></button></div>}
      {notice && <div className="message" role="status">{notice}</div>}
      {busy && <div className="loading-overlay"><div role="status"><LoaderCircle size={26} className="spin"/><strong>{busy}…</strong><span>請稍候，正在處理這次的食材。</span></div></div>}
    </main>
    <footer><span>FridgeChef AI <span className="dot-separator">·</span> 冰箱料理魔法師</span><span>把食材用好，把日子煮好。</span></footer>
  </div>;
}
