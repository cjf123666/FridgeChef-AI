import { z } from "zod";
export const ingredientSchema = z.object({ name: z.string().trim().min(1).max(30), quantity: z.string().trim().max(30), confidence: z.enum(["high", "medium", "low"]).default("medium") });
export type Ingredient = z.infer<typeof ingredientSchema>;
export const preferencesSchema = z.object({ minutes: z.number().int().min(15).max(60), servings: z.number().int().min(1).max(6), taste: z.enum(["清淡", "家常", "微辣", "香辣"]), diet: z.enum(["不限", "蛋奶素", "全素"]), exclusions: z.array(z.string().trim().min(1).max(20)).max(12) });
export type Preferences = z.infer<typeof preferencesSchema>;
export const recipeSchema = z.object({ title: z.string().min(1).max(40), description: z.string().min(1).max(160), minutes: z.number().int().min(1).max(60), ingredients: z.array(z.object({ name: z.string().min(1).max(30), quantity: z.string().max(40) })).min(2).max(18), steps: z.array(z.string().min(1).max(500)).min(3).max(12), tip: z.string().max(200) });
export type Recipe = z.infer<typeof recipeSchema>;
const groups: Record<string, string[]> = {
  "雞蛋": ["雞蛋", "鸡蛋", "蛋液", "蛋白", "蛋黃", "蛋黄", "鹹蛋", "咸蛋", "鴨蛋", "鸭蛋", "蛋麵", "蛋面"],
  "牛奶": ["奶", "乳", "起司", "芝士", "黃油", "黄油", "奶油"], "花生": ["花生"],
  "海鮮": ["魚", "鱼", "蝦", "虾", "蟹", "貝", "贝", "蛤", "蠔", "蚝", "魷", "鱿", "海鮮", "海鲜", "鯷", "鲣"],
  "大豆": ["豆腐", "豆漿", "豆浆", "黃豆", "黄豆", "大豆", "醬油", "酱油", "豆瓣", "豆豉", "味噌", "毛豆", "腐竹"],
  "麩質": ["麵", "面粉", "麥", "麦", "醬油", "酱油", "麩", "麸", "麵包", "面包"],
};
const meat = ["豬", "猪", "牛肉", "羊", "雞肉", "鸡肉", "雞胸", "鸡胸", "雞腿", "鸡腿", "鴨", "鸭", "鵝", "鹅", "肉", "火腿", "培根", "魚", "鱼", "蝦", "虾", "蟹", "蠔", "蚝", "貝", "贝", "蛤", "魷", "鱿", "高湯", "高汤", "雞精", "鸡精", "明膠", "明胶"];
export function forbiddenTerms(p: Preferences) { return [...p.exclusions.flatMap(x => groups[x] || [x]), ...(p.diet !== "不限" ? meat : []), ...(p.diet === "全素" ? [...groups["雞蛋"], ...groups["牛奶"], "蜂蜜"] : [])]; }
export function allowed(recipe: Recipe, p: Preferences) { const text = [recipe.title, ...recipe.ingredients.map(x => x.name), ...recipe.steps, recipe.tip].join(" "); return recipe.minutes <= p.minutes && !forbiddenTerms(p).some(term => text.includes(term)); }
const aliases: Record<string, string> = { "番茄": "番茄", "西紅柿": "番茄", "西红柿": "番茄", "鸡蛋": "雞蛋", "蛋": "雞蛋", "小白菜": "青江菜", "上海青": "青江菜", "蘑菇": "菇類", "香菇": "菇類", "鮮香菇": "菇類", "白蘑菇": "菇類", "菇類": "菇類" };
export function sameFood(a: string, b: string) { return (aliases[a] || a) === (aliases[b] || b); }
export function missing(recipe: Recipe, items: Ingredient[]) { return recipe.ingredients.filter(x => !items.some(i => sameFood(x.name, i.name))); }
export const sampleIngredients: Ingredient[] = [ { name: "番茄", quantity: "2 顆", confidence: "high" }, { name: "雞蛋", quantity: "3 顆", confidence: "high" }, { name: "青江菜", quantity: "2 株", confidence: "high" }, { name: "豆腐", quantity: "1 盒", confidence: "medium" }, { name: "香菇", quantity: "4 朵", confidence: "medium" } ];
export const pantryNames = ["食用油", "鹽", "醬油", "蒜頭"];
const make = (title: string, description: string, minutes: number, ingredients: [string, string][], steps: string[], tip: string): Recipe => ({ title, description, minutes, ingredients: ingredients.map(([name, quantity]) => ({ name, quantity })), steps, tip });
export const sampleRecipes: Recipe[] = [
  make("番茄炒蛋", "酸甜番茄裹上柔嫩炒蛋，一道熟悉又下飯的家常味。", 15, [["番茄", "2 顆"], ["雞蛋", "3 顆"], ["食用油", "1 大匙"], ["鹽", "少許"]], ["番茄洗淨切塊；雞蛋打散，加入少許鹽。", "鍋中加入一半食用油，倒入蛋液，炒至完全凝固後盛起。", "加入剩餘食用油與番茄，中火翻炒 3 至 5 分鐘，直到番茄軟化出汁。", "放回雞蛋，拌炒 1 分鐘，以剩餘的鹽調味後盛盤。"], "番茄出汁後再放回炒蛋，口感更嫩。"),
  make("香菇燴豆腐", "豆腐吸飽菇香，用最簡單的食材做出溫暖的一餐。", 20, [["豆腐", "1 盒"], ["香菇", "4 朵"], ["醬油", "1 大匙"], ["食用油", "1 小匙"], ["蒜頭", "2 瓣"]], ["豆腐切成小塊，香菇洗淨切片，蒜頭切碎。", "熱鍋加入食用油，炒香蒜頭與香菇約 2 分鐘。", "加入豆腐、醬油與 100 毫升清水，小火燉煮 8 分鐘。", "輕推豆腐使其均勻入味，煮至湯汁略收乾後盛盤。"], "用鍋鏟輕推豆腐，避免頻繁翻動。"),
  make("蒜香青江菜", "大火快炒保留青菜的爽脆，清爽搭配每一餐。", 15, [["青江菜", "2 株"], ["蒜頭", "2 瓣"], ["食用油", "1 小匙"], ["鹽", "少許"]], ["青江菜逐葉洗淨，菜梗與菜葉分開；蒜頭切片。", "鍋中熱油，中火炒香蒜片約 20 秒。", "先放菜梗炒 1 分鐘，再放菜葉與 2 大匙水。", "翻炒至熟透但仍翠綠，加入少許鹽，立即盛盤。"], "洗淨後瀝乾水分，菜梗先下鍋。"),
  make("番茄豆腐湯", "一碗酸甜清爽的湯，讓番茄與豆腐的原味說話。", 15, [["番茄", "2 顆"], ["豆腐", "1 盒"], ["食用油", "1 小匙"], ["鹽", "少許"]], ["番茄洗淨切塊，豆腐切成小塊。", "鍋中加入食用油，炒軟番茄約 3 分鐘。", "倒入 500 毫升清水，煮沸後加入豆腐。", "小火煮 5 分鐘，加少許鹽調味後盛出。"], "用清水煮湯，保留食材的清甜。"),
  make("清炒雙蔬", "番茄和青江菜的清甜，在鍋裡輕輕相遇。", 15, [["番茄", "1 顆"], ["青江菜", "2 株"], ["食用油", "1 小匙"], ["鹽", "少許"]], ["番茄洗淨切塊，青江菜洗淨切段。", "鍋中熱油，放入番茄炒 2 分鐘。", "加入青江菜與 2 大匙水，翻炒至菜梗熟透。", "加少許鹽調味，拌勻後立即盛盤。"], "青菜熟透後就起鍋，保留清爽口感。"),
  make("清炒香菇", "把香菇煎出香氣，簡單調味就很美味。", 15, [["香菇", "4 朵"], ["食用油", "1 小匙"], ["鹽", "少許"]], ["香菇洗淨，瀝乾後切片。", "熱鍋加入食用油，放入香菇，中火煎 2 分鐘。", "翻面繼續炒熟，必要時加 1 大匙水。", "炒至香菇熟透，加入少許鹽，拌勻起鍋。"], "香菇瀝乾後再炒，更容易煎出香氣。"),
];
export function demoRecipes(items: Ingredient[], p: Preferences): Recipe[] {
  if (!["清淡", "家常"].includes(p.taste) || p.servings !== 2) return [];
  return sampleRecipes.filter(r => allowed(r, p) && r.ingredients.filter(i => !pantryNames.includes(i.name)).every(i => items.some(x => sameFood(i.name, x.name)))).slice(0, 3);
}
